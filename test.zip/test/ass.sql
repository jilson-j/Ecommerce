-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 06, 2021 at 01:39 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ass`
--

-- --------------------------------------------------------

--
-- Table structure for table `addresses`
--

CREATE TABLE `addresses` (
  `id` int(10) UNSIGNED NOT NULL,
  `address1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zip` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `addresses`
--

INSERT INTO `addresses` (`id`, `address1`, `address2`, `city`, `state`, `zip`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'Chennai', 'Trichy', 'Ashok Nagar', 'Tamilnadu', '600089', '6', '2021-03-22 00:32:50', '2021-03-22 00:32:50');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `email`, `password`, `created_at`, `updated_at`) VALUES
(1, 'admin@gmail.com', '123123123', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `carts`
--

INSERT INTO `carts` (`id`, `product_id`, `product_name`, `user_id`, `price`, `quantity`, `total`, `tax`, `created_at`, `updated_at`) VALUES
(2, '2', 'Bat(MRF)', '1', '2500', '2', '5000', NULL, '2021-03-21 23:47:03', '2021-03-21 23:47:03');

-- --------------------------------------------------------

--
-- Table structure for table `checkouts`
--

CREATE TABLE `checkouts` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `checkouts`
--

INSERT INTO `checkouts` (`id`, `product_id`, `product_name`, `user_id`, `price`, `quantity`, `total`, `tax`, `created_at`, `updated_at`) VALUES
(1, '1', 'Bag', '1', '200', '2', '400', '7', '2021-03-21 23:48:54', '2021-03-21 23:48:54'),
(2, '2', 'Bat(MRF)', '1', '2500', '2', '5000', '7', '2021-03-21 23:48:54', '2021-03-21 23:48:54');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2021_03_21_063756_create_products_table', 1),
(4, '2021_03_21_140815_create_carts_table', 2),
(5, '2021_03_21_173133_create_checkouts_table', 3),
(6, '2021_03_22_055202_create_addresses_table', 4),
(7, '2021_05_05_174535_create_admins_table', 5),
(8, '2021_05_06_074914_create_product_preview_images_table', 6);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shortdescription` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `image`, `quantity`, `price`, `created_at`, `updated_at`, `description`, `shortdescription`) VALUES
(4, 'Table', 'http://127.0.0.1:8000/img/uploads/productimage/blog-2-370x270.jpg', '2', '22', '2021-05-06 02:17:17', '2021-05-06 02:17:17', 'this is a table', 'this is a table'),
(5, 'Table', 'http://127.0.0.1:8000/img/uploads/productimage/bg5.jpg', '1', '82', '2021-05-06 02:22:37', '2021-05-06 02:22:37', 'table', 'table'),
(6, 'Modern Chair', 'http://127.0.0.1:8000/img/uploads/productimage/product-2-370x270.jpg', '2', '94', '2021-05-06 03:56:41', '2021-05-06 03:56:41', 'this is the testing area', 'this is the testing area');

-- --------------------------------------------------------

--
-- Table structure for table `product_preview_images`
--

CREATE TABLE `product_preview_images` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `preview_images` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_preview_images`
--

INSERT INTO `product_preview_images` (`id`, `product_id`, `preview_images`, `created_at`, `updated_at`) VALUES
(1, '5', 'http://127.0.0.1:8000/img/uploads/productImageHover/20210506075237-blog-5-370x270.jpg', '2021-05-06 02:22:37', '2021-05-06 02:22:37'),
(2, '5', 'http://127.0.0.1:8000/img/uploads/productImageHover/20210506075237-blog-6-370x270.jpg', '2021-05-06 02:22:38', '2021-05-06 02:22:38'),
(3, '5', 'http://127.0.0.1:8000/img/uploads/productImageHover/20210506075237-blog-image-fullscren-1-1920x700.jpg', '2021-05-06 02:22:38', '2021-05-06 02:22:38'),
(4, '6', 'http://127.0.0.1:8000/img/uploads/productImageHover/20210506092641-product-3-370x270.jpg', '2021-05-06 03:56:41', '2021-05-06 03:56:41'),
(5, '6', 'http://127.0.0.1:8000/img/uploads/productImageHover/20210506092641-product-4-370x270.jpg', '2021-05-06 03:56:42', '2021-05-06 03:56:42'),
(6, '6', 'http://127.0.0.1:8000/img/uploads/productImageHover/20210506092641-product-5-370x270.jpg', '2021-05-06 03:56:42', '2021-05-06 03:56:42');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'joe', 'joe@gmail.com', '$2y$10$5BTJ1IvHB3bF2XMVeGX8I.FbGIeeXenOYZznJipAp5tLYvVJ2oh2O', 'Ruerp8sNcuocLwz1hzVM98W1dhNFIX57LxPvj0N3KskMBOcajmHXG6W3yXuz', '2021-03-21 08:32:11', '2021-03-21 08:32:11'),
(2, 'testtest', 'tester@gmail.com', '$2y$10$gaVcpkVHXw3/9UukwLtxXOyL3i713Re09m9MyA8HY5pMND9f/EzI.', 'moTnjY5ixNYRkXUknX3Qp6V2QExjVd58W5bUp0a7hyHYMUYubnT7fHlNCNCT', '2021-03-22 00:20:45', '2021-03-22 00:20:45'),
(4, 'testtest', 'tester1@gmail.com', '$2y$10$6lbx7EoC6nXQg8cif55vgudAO/bQ/gpTd1jxFq0mR0vFhSFdk1S0q', NULL, '2021-03-22 00:32:02', '2021-03-22 00:32:02'),
(6, 'testtest', 'tester11@gmail.com', '$2y$10$y5l0tF4IZcC5rPgHWPdCTOQKTpbs7hrflZnD3zPFt0famqwB9gaya', NULL, '2021-03-22 00:32:50', '2021-03-22 00:32:50'),
(8, 'admin', 'admin@gmail.com', '$2y$10$ZZmyGum0cmKucWCuzoGbWuDLKszl.HQPCFwvZ7FIah3.nUYDrjwhi', '0Ci7Ps3hI1PUp0vERVqAAAaUUZQCEJWmvXspLTHSO6kCnKoxw8LTa3iwXLlT', '2021-05-05 22:45:14', '2021-05-05 22:45:14');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addresses`
--
ALTER TABLE `addresses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `checkouts`
--
ALTER TABLE `checkouts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_preview_images`
--
ALTER TABLE `product_preview_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addresses`
--
ALTER TABLE `addresses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `checkouts`
--
ALTER TABLE `checkouts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `product_preview_images`
--
ALTER TABLE `product_preview_images`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
