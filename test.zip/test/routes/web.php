<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/', 'HomeController@product')->name('product');
Route::post('search-product', 'HomeController@search')->name('search');
Route::get('/product-details/{id}', 'HomeController@product_details')->name('product_details');



//admin


Route::get('/admin', 'AdminController@index')->name('admin');
Route::post('/admin-login', 'AdminController@login')->name('admin-login');
Route::get('/admin-dashboard', 'AdminController@dashboard')->name('admin-dashboard');
Route::post('/admin-logout', 'Auth\LoginController@logout')->name('adminlogout');
Route::get('/admin-add-product', 'AdminController@addproduct')->name('addproduct');
Route::post('admin/saveproduct', 'AdminController@saveproduct')->name('saveproduct');
Route::get('/delete/{id}', 'AdminController@delete_product')->name('delete');
Route::get('/edit/{id}', 'AdminController@editproduct')->name('edit');
Route::post('admin/update-product/{id}', 'AdminController@update_product')->name('update_product');
