<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class product extends Model
{
    public function productpreviewimage()
    {
        return $this->belongsTo(ProductPreviewImage::class, 'id', 'product_id');
    }
}
