<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use App\User;
use App\Checkout;
use App\Address;


class ApiController extends Controller
{
    public function create_product(Request $request){

        $create_product=new Product();
        $create_product->name=$request->name;
        $create_product->price=$request->price;
        $create_product->quantity=$request->quantity;
        $create_product->save();
        return "Item Created";

    }
    public function create_user(Request $request){

        $create_user=new user();
        $create_user->name=$request->first_name.$request->last_name;
        $create_user->first_name=$request->first_name;
        $create_user->last_name=$request->last_name;
        $create_user->email=$request->email;
        $create_user->password=bcrypt($request->password);
        $create_user->save();

        $address=new Address();
        $address->address1=$request->address1;
        $address->address2=$request->address2;
        $address->state=$request->state;
        $address->city=$request->city;
        $address->zip=$request->zip;
        $address->user_id=$create_user->id;
        $address->save();

        
       
        return "user Created";

    }
}
