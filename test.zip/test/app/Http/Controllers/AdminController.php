<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Admin;
use App\Product;
use App\ProductPreviewImage;
use Auth;
class AdminController extends Controller
{
   public function index(){
       return view('admin.login');
   }
   public function login(Request $request){
      $admin=Admin::where('email',$request->email)->where('password',$request->password)->first();

    if($admin){ 
        
        return redirect()->route('admin-dashboard')->with('message', 'Login Sucess');
    } 
    else{ 
        
        return redirect()->back()->with('error', 'Username or Password Mismatch');
    } 
    }
    public function dashboard(Request $request){
        $product=Product::all();
        return view('admin.dashboard',compact('product'));
      }

      
      public function addproduct(Request $request){
        return view('admin.addproduct');
      }
      public function saveproduct(Request $request){
        
        $this->validate($request, [
            'productname'  => 'required',
            'productimage' => 'required',
          
            'description'  => 'required',
            'price'        => 'required',
            
            
           
        ]);
      

        if(request()->productimage){
            $productimageupload= $request->productimage;
            $productimage= $productimageupload->getClientOriginalName();
            $image=url('img/uploads/productimage/').'/'.$productimage;
            $valtest = $productimageupload->move(public_path('/img/uploads/productimage/'),$productimage);
        }
       
       $product = new Product();
       $product->name  = $request->productname;
       $product->image = $image;
       $product->description  = $request->description;
       $product->shortdescription = $request->short_description;
       $product->price        = $request->price;
       $product->quantity        = $request->quantity;
       $product->save();

       //Multiple image upload
       $images = $request->file('productImageHover');
        if ($request->hasFile('productImageHover')):
            foreach ($images as $item):
                $var = date_create();
                $time = date_format($var, 'YmdHis');
                $imageName = $time . '-' . $item->getClientOriginalName();
                $filename = url('/') . '/img/uploads/productImageHover/' . $imageName;
                $path = public_path() . '/img/uploads/productImageHover';
                $item->move($path, $filename);
                $arr[] = $imageName;
            endforeach;
            $productImageHovermultipleimage = $arr;
        else:
            $productImageHovermultipleimage = '';
        endif;
        if ($request->hasFile('productImageHover')){
            foreach($productImageHovermultipleimage as $image)
            {
                $productpreviewimages = new ProductPreviewImage();
                $productpreviewimages->product_id = $product->id;
                $productpreviewimages->preview_images = url('/img/uploads/productImageHover/').'/' .$image;
                $productpreviewimages->save();
            }
        }
       return redirect()->back()->with('success','Product Added Successfully.'); 

      }

      public function editproduct($id){
       
        $editproduct=Product::with('productpreviewimage')->where('id',$id)->first();
        $ProductPreviewImage=ProductPreviewImage::where('product_id',$id)->get();
        return view('admin.editproduct',compact('editproduct','ProductPreviewImage'));
    }

    public function update_product(Request $request,$id){
        $product =Product::with('productpreviewimage')->find($id);
        $pre=ProductPreviewImage::select('preview_images')->where('product_id',$id)->get();
        if(request()->productimage){
            $productimageupload= $request->productimage;
            $productimage= $productimageupload->getClientOriginalName();
            $image=url('img/uploads/productimage/').'/'.$productimage;
            $valtest = $productimageupload->move(public_path('/img/uploads/productimage/'),$productimage);
        }
        else{
            $image=$product->image;
        }
      
       $product->name  = $request->productname;
       $product->image = $image;
       $product->description  = $request->description;
       $product->shortdescription = $request->short_description;
       $product->price        = $request->price;
       $product->quantity        = $request->quantity;
       $product->save();
        if($request->file('productImageHover')!=''){
            ProductPreviewImage::where('product_id',$product->id)->delete();
        }
          //Multiple image upload
          $images = $request->file('productImageHover');
          if ($request->hasFile('productImageHover')):
              foreach ($images as $item):
                  $var = date_create();
                  $time = date_format($var, 'YmdHis');
                  $imageName = $time . '-' . $item->getClientOriginalName();
                  $filename = url('/') . '/img/uploads/productImageHover/' . $imageName;
                  $path = public_path() . '/img/uploads/productImageHover';
                  $item->move($path, $filename);
                  $arr[] = $imageName;
              endforeach;
              $productImageHovermultipleimage = $arr;
          else:
              $productImageHovermultipleimage = '';
          endif;
          if ($request->hasFile('productImageHover')){
              foreach($productImageHovermultipleimage as $image)
              {
                  $productpreviewimages = new ProductPreviewImage();
                  $productpreviewimages->product_id = $product->id;
                  $productpreviewimages->preview_images = url('/img/uploads/productImageHover/').'/' .$image;
                  $productpreviewimages->save();
              }
          }
       return redirect()->back()->with('success','Product Updated Successfully.'); 
    }
    

      public function delete_product(Request $request,$id){
        $product =Product::find($id);
        $product->delete();
         $productpreviewimages =ProductPreviewImage::where('product_id',$id);
         $productpreviewimages->delete();
         return redirect()->back()->with('success','Product Deleted Successfully.'); 
     }
}
