<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Product;

use App\ProductPreviewImage;


class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth')->except(['product','product_details','search']);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   $products=Product::all();
        return view('welcome',compact('products'));
    }
    public function product()
    {
        $product=Product::paginate(5);
        return view('products',compact('product'));
    }
    public function search(Request $request)
    {
        $product=Product::where('name',$request->name)->first();
        if($product){
            $product=Product::where('name',$request->name)->get()->paginate(5);
        }
        else{
            $product=Product::paginate(5);
        }
        return view('products',compact('product'));
    }
    
   
    public function product_details($id)
    {
        $product_details=Product::find($id);
        $product=Product::all();
       
         $ProductPreviewImage=ProductPreviewImage::where('product_id',$id)->get();

        return view('product-details',compact('product_details','product','ProductPreviewImage'));
    }
   
   

    
    
}
