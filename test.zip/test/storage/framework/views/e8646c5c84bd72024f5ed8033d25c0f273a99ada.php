<?php $__env->startSection('content'); ?>
<!-- Page Content -->
<div class="page-heading about-heading header-text" style="background-image: url(/images/heading-6-1920x500.jpg);">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="text-content">
              <h4>Lorem ipsum dolor sit amet</h4>
              <h2>Product Details</h2>
            </div>
          </div>
        </div>
      </div>
    </div>

   
    <div class="products">
      <div class="container">
        <div class="row">
          <div class="col-md-4 col-xs-12">
            <div>
            <?php if($product_details->image==""): ?>
              <img src="/images/product.jpg" alt="" class="img-fluid wc-image">
              <?php else: ?>
              <img src="<?php echo e($product_details->image); ?>" alt="" class="img-fluid wc-image">
              <?php endif; ?>
            </div>
            <br>
            
            <div class="row">
            <?php $__currentLoopData = $ProductPreviewImage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ppi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-4">
            
                
                  <img src="<?php echo e($ppi->preview_images); ?>" alt="" class="img-fluid" width="400px" height="400px">
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
             
            
              
              
            </div>
          </div>

          <div class="col-md-8 col-xs-12">
            <form action="/addcart" method="post" class="form">
            <?php echo csrf_field(); ?>
              <h2><?php echo e($product_details->name); ?></h2>

              <br>

              <p class="lead">
                <small><del> $999.00</del></small><strong class="text-primary">$<?php echo e($product_details->price); ?></strong>
              </p>

              <br>

              <p class="lead">
              <?php echo e($product_details->shortdescription); ?>

              </p>

              <br> 

              <div class="row">
                
                <div class="col-sm-8">
                  <label class="control-label">Quantity</label>

                  <div class="row">
                    <div class="col-sm-6">
                      <div class="form-group">
                        <input type="text" class="form-control" value="<?php echo e($product_details->quantity); ?>"  name="quantity">
                      </div>
                    </div>
                   
                    <input type="hidden" class="form-control" name="price" value="<?php echo e($product_details->price); ?>">
                    <input type="hidden" class="form-control" name="product_id" value="<?php echo e($product_details->id); ?>">
                    <input type="hidden" class="form-control" name="product_name" value="<?php echo e($product_details->name); ?>">

                    <?php 
                    // $test= App\Cart::where('user_id',Auth::user()->id)->get();

                    
                    // $qty=2;
                    //   $price=2500*2;
                    //   $taxRate=21.25;
                    //   $tax=$price*$taxRate/100;
                    //   $total=$price+$tax;
                    //   $calculatedTaxRate=(($total-$price)/$price)*100;   
                    ?>
                     
                    <?php if(Auth::user()): ?>
                    <input type="hidden" class="form-control" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                    <?php else: ?>
                    <?php endif; ?>
                   
                    <div class="col-sm-6">
                      <button type="submit" class="btn btn-primary btn-block" disabled>Add to Cart</button>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>

    <div class="latest-products">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-heading">
              <h2>Similar Products</h2>
              <a href="/">view more <i class="fa fa-angle-right"></i></a>
            </div>
          </div>
          <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-4">
            <div class="product-item">
              <a href="/product-details/<?php echo e($pro->id); ?>">
              <?php if($pro->image==""): ?>
              <img src="/images/product.jpg" alt="" class="img-fluid wc-image">
              <?php else: ?>
              <img src="<?php echo e($pro->image); ?>" alt="" class="img-fluid wc-image">
              <?php endif; ?>
              </a>
              <div class="down-content">
                <h4><?php echo e($pro->name); ?></h4>
                <h6><small><del>$999.00 </del></small> $<?php echo e($pro->price); ?></h6>
              </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          

          
        </div>
      </div>
    </div>

   

    



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>