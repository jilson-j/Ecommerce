@extends('layouts.app')

@section('content')

<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">

<style>
.table>tbody>tr>td,
.table>tfoot>tr>td {
  vertical-align: middle;
}

@media screen and (max-width: 600px) {
  table#cart tbody td .form-control {
    width: 20%;
    display: inline !important;
  }
  .actions .btn {
    width: 36%;
    margin: 1.5em 0;
  }
  .actions .btn-info {
    float: left;
  }
  .actions .btn-danger {
    float: right;
  }
  table#cart thead {
    display: none;
  }
  table#cart tbody td {
    display: block;
    padding: .6rem;
    min-width: 320px;
  }
  table#cart tbody tr td:first-child {
    background: #333;
    color: #fff;
  }
  table#cart tbody td:before {
    content: attr(data-th);
    font-weight: bold;
    display: inline-block;
    width: 8rem;
  }
  table#cart tfoot td {
    display: block;
  }
  table#cart tfoot td .btn {
    display: block;
  }
}
</style>
<!-- Page Content -->
<div class="page-heading about-heading header-text" style="background-image: url(/images/heading-6-1920x500.jpg);">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="text-content">
              <h4>Lorem ipsum dolor sit amet</h4>
              <h2>Product Details</h2>
            </div>
          </div>
        </div>
      </div>
    </div>

   
<div class="container">
  <table id="cart" class="table table-hover table-condensed">
    <thead>
      <tr>
        <th style="width:50%">Product</th>
        <th style="width:10%">Price</th>
        <th style="width:8%">Quantity</th>
        <th style="width:22%" class="text-center">Subtotal</th>
        <th style="width:10%"></th>
      </tr>
    </thead>
    @foreach($cart as $cat)
    <tbody>
      <tr>
        <td data-th="Product">
          <div class="row">
            <div class="col-sm-2 hidden-xs"><img src="/images/product.jpg" width="50px"alt="..." class="img-responsive" /></div>
            <div class="col-sm-10">
              <h4 class="nomargin">{{$cat->product_name}}</h4>
              <p>Quis aute iure reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Lorem ipsum dolor sit amet.</p>
            </div>
          </div>
        </td>
        <td data-th="Price">${{$cat->price}}</td>
        <td data-th="Quantity">
          <input type="number" class="form-control text-center" value="{{$cat->quantity}}" readonly>
        </td>
        <td data-th="Subtotal" class="text-center">{{$cat->total}}</td>
        <td class="actions" data-th="">
          <button class="btn btn-info btn-sm"><i class="fa fa-refresh"></i></button>
          <a href="/delete/{{$cat->id}}"> <button class="btn btn-danger btn-sm"><i class="fa fa-trash-o"></i></button></a>
        </td>
      </tr>
    </tbody>
    @endforeach
    <tfoot>
      
      <tr>
        <td><a href="/products" class="btn btn-warning"><i class="fa fa-angle-left"></i> Continue Shopping</a></td>
        <td colspan="2" class="hidden-xs"></td>
        <td class="hidden-xs text-center"><strong>Total ${{$cat->sum('total')}}</strong></td>
        <td>
        <form method="post" action="/addcheckout">
        @csrf
        @foreach($cart as $cat)
        <input type="hidden" name="product_name[]" value="{{$cat->product_name}}">
        <input type="hidden" name="price[]" value="{{$cat->price}}">
        <input type="hidden" name="quantity[]" value="{{$cat->quantity}}">
        <input type="hidden" name="product_id[]" value="{{$cat->product_id}}">
        <input type="hidden" name="user_id[]" value="{{Auth::user()->id}}">

        @endforeach

        <button type="submit"class="btn btn-success btn-block">Checkout <i class="fa fa-angle-right"></i></button>
        </form>
        </td>
      </tr>
    </tfoot>
  </table>
</div>



@endsection
