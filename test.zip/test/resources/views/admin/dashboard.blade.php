 
@extends('layouts.admin')
@section('content')
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css">

<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<div class="container">
<div class="w3-container w3-dark-light">
  <h1>Product List</h1>
</div>

@if(session()->has('success'))
    <div class="alert alert-success">
        {{ session()->get('success') }}
    </div>
@endif
<table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Name</th>
                <th>Image</th>
                <th>Description</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        @foreach($product as $pro)
            <tr>
                <td> {{$pro->name}}</td>
                <td>
                @if($pro->image=="")
                <h2>No Image</h2>
                @else
                <img src="{{$pro->image}}" width="100px" height="100px">
                @endif
                </td>
                <td>{{$pro->shortdescription}}</td>
                <td>{{$pro->quantity}}</td>
                <td>{{$pro->price}}</td>
                <td>Active</td>
                <td><a href="/edit/{{$pro->id}}">edit<a>&nbsp;<a href="/delete/{{$pro->id}}">delete<a></td>
            </tr>
          @endforeach
           
        </tbody>
        <tfoot>
           
        </tfoot>
    </table>
    </div>
</body>

<script>
$(document).ready(function() {
    $('#example').DataTable();
} );
</script>
@endsection
            
            

 

  

  




