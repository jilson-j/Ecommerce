 
@extends('layouts.admin')
@section('content')



<div class="container">
<div class="w3-container w3-dark-light">
  <h1>Edit Product</h1>
</div>
<div class="" style="background:#212529;color:white ">
<form action="{{url('admin/update-product/'.$editproduct->id)}}"class="col-lg-12" method="POST" enctype="multipart/form-data">
                            @csrf
<h4 class="title">Edit your Product description and information</h4>

@if(session()->has('success'))
    <div class="alert alert-success">
        {{ session()->get('success') }}
    </div>
@endif
    <div class="row">
        <div class="col-md-6">
            <!-- product name -->
            <div class="form-group">        
            <label for="productname">Product Name</label>                        
            <input type="text" name="productname" class="form-control"  value="{{$editproduct->name}}"placeholder="Product Name">
            @if ($errors->has('productname'))
                <div style="color:red">{{ $errors->first('productname') }}</div>
            @endif
            </div> 
        </div>
        <div class="col-md-6">
            <!-- product name -->
            <div class="form-group">        
            <label for="productname">Quantity</label>                        
            <input type="text" name="quantity" class="form-control"  value="{{$editproduct->quantity}}"placeholder="quantity">
            @if ($errors->has('quantity'))
                <div style="color:red">{{ $errors->first('quantity') }}</div>
            @endif
            </div> 
        </div>
        
    </div>   
                            
                            <!-- product description -->
    <div class="form-group">       
        <label for="description">Description</label> 
        <textarea name="description" class="form-control" value="" rows="4" cols="50">{{$editproduct->description}}</textarea>
        @if ($errors->has('description'))
            <div style="color:red">{{ $errors->first('description') }}</div>
        @endif
    </div>


    <div class="form-group">       
        <label for="description">Short Description</label> 
        <textarea name="short_description" class="form-control" value="" rows="2" cols="20">{{$editproduct->shortdescription}}</textarea>
        @if ($errors->has('short_description'))
            <div style="color:red">{{ $errors->first('short_description') }}</div>
        @endif
    </div>
                            
    <!-- product price -->
    <div class="form-group">  
    <label for="price">Price</label>                              
    <div class="range-slider">
    <!-- <input class="range-slider__range" type="range" name="price" value="0" min="0" max="500"> -->
    <input type="range" name="price" class="range-slider__range" id="rangeid" value="{{$editproduct->price}}" min="1" max="100" oninput="outputrangeid.value = rangeid.value">
    @if ($errors->has('price'))
                <div style="color:red">{{ $errors->first('price') }}</div>
            @endif
    <output name="ageOutputName" class="range-slider__value" id="outputrangeid">{{$editproduct->price}} <small>$</small></output>
    
    <!-- <span class="range-slider__value">0 <small>$</small></span> -->
</div> 

</div> 
             

<div class="row">
<div class="col-md-6">
<!-- product image -->
<div class="form-group">
<label>Upload your Product image here</label>
<div class="upload-img">
    <span><i class="zmdi zmdi-image-alt"></i>Click here or drop files to upload</span>
    <input id="sfileupload" type="file" class="form-control-file"  value="{{$editproduct->image}}" name="productimage" accept="image/*">
    @if ($errors->has('productimage'))
    <div style="color:red">{{ $errors->first('productimage') }}</div>
@endif  
    
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script language="javascript" type="text/javascript">
        $(function () {
            $("#sfileupload").change(function () {
                if (typeof (FileReader) != "undefined") {
                    var dvPreview = $("#sdvPreview");
                    dvPreview.html("");
                    var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.jpg|.jpeg|.gif|.png|.bmp)$/;
                    $($(this)[0].files).each(function () {
                        var file = $(this);
                        if (regex.test(file[0].name.toLowerCase())) {
                            var reader = new FileReader();
                            reader.onload = function (e) {
                                var img = $("<img />");
                                img.attr("style", "height:100px;width: 100px");
                                img.attr("src", e.target.result);
                                dvPreview.append(img);
                            }
                            reader.readAsDataURL(file[0]);
                        } else {
                            alert(file[0].name + " is not a valid image file.");
                            dvPreview.html("");
                            return false;
                        }
                    });
                } else {
                    alert("This browser does not support HTML5 FileReader.");
                }
            });
        });
    </script>                                    
</div>
<div id="sdvPreview">
<img src="{{$editproduct->image}}" height="100px";width="100px";>
</div>
</div>
</div>
<div class="col-md-6">
<!-- product hover image -->
<div class="form-group">
<label>Upload your Product hover image here</label>
<div class="upload-img">
    <span><i class="zmdi zmdi-image-alt"></i>Click here or drop files to upload</span>
    <input id="fileupload" type="file" class="form-control-file" value="{{old('productImageHover')}}" name="productImageHover[]" multiple="multiple" />  
    @if ($errors->has('productImageHover'))
    <div style="color:red">{{ $errors->first('productImageHover') }}</div>
@endif                                  
</div>

<div id="dvPreview">
@foreach($ProductPreviewImage as $ppp)
<img src="{{$ppp->preview_images}}" height="100px";width="100px";>
@endforeach
</div>
</div>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script language="javascript" type="text/javascript">
$(function () {
    $("#fileupload").change(function () {
        if (typeof (FileReader) != "undefined") {
            var dvPreview = $("#dvPreview");
            dvPreview.html("");
            var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.jpg|.jpeg|.gif|.png|.bmp)$/;
            $($(this)[0].files).each(function () {
                var file = $(this);
                if (regex.test(file[0].name.toLowerCase())) {
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        var img = $("<img />");
                        img.attr("style", "height:100px;width: 100px");
                        img.attr("src", e.target.result);
                        dvPreview.append(img);
                    }
                    reader.readAsDataURL(file[0]);
                } else {
                    alert(file[0].name + " is not a valid image file.");
                    dvPreview.html("");
                    return false;
                }
            });
        } else {
            alert("This browser does not support HTML5 FileReader.");
        }
    });
});
</script>
</div>
</div>  


<div class="submit-btn">      
    <button  class="btn btn-raised btn-primary btn-round waves-effect">Update</button>
</div>                           

</form>
</div>
</div>
</body>

<script>

</script>
@endsection
            
            

 

  

  




